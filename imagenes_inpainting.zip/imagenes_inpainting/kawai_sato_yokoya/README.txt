These images are shown in the web page: 
http://yokoya.naist.jp/research/inpainting/

are extracted from 
http://yokoya.naist.jp/~norihi-k/researchimg/img/

by their names ex:
http://yokoya.naist.jp/~norihi-k/researchimg/img/a134.bmp
